module ApplicationHelper
    def liked?(tweet)
        tweet.likes.where(user_id: current_user[:id]).any?
    end
end
