class ApiController < ApplicationController
        
  
      def index
        tweets = Tweet.all

    respond_to do |format|
      format.json { render json: tweets }
      format.xml  { render xml: tweets }
      end
      end

      def new
        news_arr = []
        jtweets = Tweet.last(50)
         jtweets.each do |t|
         news_arr << {
            id: t.id,
            content: t.content,
            user_id: t.user_id,
            likes_count: t.likes.count,
            retweets_count: Tweet.where("retweeted_id = ?", t.id).count,
            retweeted_from: Tweet.where("id = ?", t.retweeted_id).ids
          }
         end

        respond_to do |format|
          format.json { render json: news_arr }
          format.xml  { render xml: news_arr }
        end
      end  

      def between
        between_arr = []
         fecha1 = params[:fecha1]
         fecha2 = params[:fecha2]
         selected_tweets = Tweet.where(:created_at => fecha1..fecha2)
         selected_tweets.each do |t|
          between_arr << {
             id: t.id,
             content: t.content,
             user_id: t.user_id,
             likes_count: t.likes.count,
             retweets_count: Tweet.where("retweeted_id = ?", t.id).count,
             retweeted_from: Tweet.where("id = ?", t.retweeted_id).ids
           }
          end
         respond_to do |format|
          format.json { render json: between_arr }
          format.xml  { render xml: between_arr }
         end
      end

      


         
     
    
end